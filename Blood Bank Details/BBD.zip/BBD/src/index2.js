// Route the incoming request based on type (LaunchRequest, IntentRequest,
// etc.) The JSON body of the request is provided in the event parameter.

var Alexa = require('alexa-sdk');
var request = require("request")

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);

    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function() { //Executes when a new session is launched
        if (event.request.type === "LaunchRequest") {
            this.emit('LaunchIntent');
        } else if (event.request.type === "IntentRequest")  {
            this.emit('TestIntent');
        } else {
            this.emit('AMAZON.StopIntent');
        }
    },

    'LaunchIntent': function() {
        var speechOutput = "Welcome! Do you want to know Blood Bank Details?"
        var reprompt = "Do you want to hear Blood Bank Details?"

        this.emit(':ask', speechOutput, reprompt);
    },

    'LanguageIntent': function() {
        this.attributes['myLangauge'] = this.event.request.intent.slots.myLangauge.value;
        this.emit(':ask', "I got it. What is you age?");
    },

    'AgeIntent': function() {
        this.attributes['myAge'] = this.event.request.intent.slots.myNumber.value;
        this.emit(':ask', "I got it.");
    },

    'TestIntent': function() {
        this.emit(':tell', "I still remember that your favorite language is, " + this.attributes['myLangauge'] + " and your age is, " +  this.attributes['myAge']);
    },
    'AMAZON.HelpIntent': function () {    
          var speechOutput = "You can say tell me a blood bank details, or, you can say exit... What can I help you with?";
            var reprompt = "What can I help you with?";
            this.emit(':ask', speechOutput, reprompt);
    },
    'AMAZON.StopIntent': function () {
          var speechOutput = "Donate Blood to save lives. Have a nice day!";
          this.emit(':tell', speechOutput);
    },
    'AMAZON.CancelIntent': function () {
          var speechOutput = "Cancelling initiated. Goodbye, Stay Safe";
          this.emit(':tell', speechOutput);
    }
};


function url() {
    return {
        url: "https://api.data.gov.in/resource/fced6df9-a360-4e08-8ca0-f283fc74ce15",
        qs: {
            "format" : "json",
            "api-key" : "579b464db66ec23bdd0000012c8c03cfc3a548a97bcb5ea2067e58ec",
            "filters[pincode]" : "201301"
        }
    }
}

