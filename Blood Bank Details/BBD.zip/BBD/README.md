# Alexa - Blood Bank Directory

Data contains state/city wise list of blood banks and other required Information like address, geo location, Contact Details, Area Pin Code, Email address, Website link, etc. The Ministry of Health and Family Welfare, Government of India has set up the National Health Portal in pursuance to the decisions of the National Knowledge Commission, to provide healthcare related information to the citizens of India. 


More infor for API:
https://data.gov.in/resources/blood-bank-directory-updated-till-last-month/api
