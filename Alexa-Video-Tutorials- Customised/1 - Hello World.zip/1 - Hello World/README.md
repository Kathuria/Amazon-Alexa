# Alexa-Hello-World - 2 Way Communication App

A very simple step by step, 12:56 minutes demo (see video at the end of read me) of developing very simple skill of 2 way communication with Alexa.

This simple app will help you understand
- How to create skill in developer.amazon.com
- How to write intents and sample utterances
- How to write skill functionality in node and upload in lambda in aws.amazon.com
- Testing a skill using https://echosim.io/

# Pre-requisite
- Create an account and login for
- https://developer.amazon.com
- https://aws.amazon.com

# Video
Watch this video to learn the steps to create sample application.

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/V0PwCFrIfwg/0.jpg)](https://www.youtube.com/watch?v=V0PwCFrIfwg&t=9s)
