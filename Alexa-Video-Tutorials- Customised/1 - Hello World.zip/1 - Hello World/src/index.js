var Alexa = require('alexa-sdk');

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context, callback);

    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function() { //Executes when a new session is launched
        this.emit('LaunchIntent');
    },

    'LaunchIntent': function() {
        this.emit(':ask', "Hello how are you?");
    },

    'HelloIntent': function() {
        var speechOutput = "Good to hear from you. You have successfully tested hello world skill. Good bye Avi.";
        
        var cardTitle = 'Hello World Card';
        
        var cardContent = 'This text will be displayed in the companion app card.';

        var imageObj = {
            //smallImageUrl: 'https://s3-eu-west-1.amazonaws.com/akimagebucket/Hello+World++small+720w+480h.png',
            smallImageUrl:"https://s3-eu-west-1.amazonaws.com/akimagebucket/word-hello-background+108h+108w.jpg",
            largeImageUrl: 'https://s3-eu-west-1.amazonaws.com/akimagebucket/Hello+World+large+1200w+800h.png'
        };
        
  
        this.emit(':tellWithCard', speechOutput, cardTitle, cardContent, imageObj);
    },
    'AMAZON.HelpIntent': function () {    
          var speechOutput = "You can say helo world, or, you can say exit... What can I help you with?";
            var reprompt = "What can I help you with?";
            this.emit(':ask', speechOutput, reprompt);
    },
    'AMAZON.StopIntent': function () {
          var speechOutput = "Stopping Services. Have a nice day!";
          this.emit(':tell', speechOutput);
    },
    'AMAZON.CancelIntent': function () {
          var speechOutput = "Cancelling initiated. Goodbye, Stay Safe";
          this.emit(':tell', speechOutput);
    }
};
