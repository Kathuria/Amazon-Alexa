// Route the incoming request based on type (LaunchRequest, IntentRequest,
// etc.) The JSON body of the request is provided in the event parameter.

var Alexa = require('alexa-sdk');

exports.handler = function(event, context, callback) {
    var alexa = Alexa.handler(event, context);

    alexa.dynamoDBTableName = 'sampleLangaugeTable'; // creates new table for session.attributes
    alexa.registerHandlers(handlers);
    alexa.execute();
};

var handlers = {
    'LaunchRequest': function() { //Executes when a new session is launched
        if (!this.attributes['myLangauge']) {
            this.emit('LaunchIntent');
        } else {
            this.emit('TestIntent');
        }
    },

    'LaunchIntent': function() {
        this.emit(':ask', "Hi, what is your favorite language?");
    },

    'LanguageIntent': function() {
        this.attributes['myLangauge'] = this.event.request.intent.slots.myLangauge.value;
        this.emit(':ask', "I got it. What is you age?");
    },

    'AgeIntent': function() {
        this.attributes['myAge'] = this.event.request.intent.slots.myNumber.value;
        this.emit(':ask', "I got it.");
    },

    'TestIntent': function() {
        this.emit(':tell', "I still remember that your favorite language is, " + this.attributes['myLangauge'] + " and your age is, " +  this.attributes['myAge']);
    },
    'AMAZON.HelpIntent': function () {    
          this.emit(':tell', "My Info is very simple skill, it takes input for your favorite language and your age. It will retain this info and speak out that info on new launch.");
    },
    'AMAZON.StopIntent': function () {
          this.emit(':tell', "Thank you for checking MyInfo skill. Have a nice day!");
    },
    'AMAZON.CancelIntent': function () {
          this.emit(':tell', "Ok, Cancelling initiated. Goodbye");
    }
};
