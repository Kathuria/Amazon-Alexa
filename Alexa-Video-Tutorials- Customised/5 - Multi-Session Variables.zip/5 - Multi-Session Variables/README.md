# Alexa - Database / Multi-Session Variables

A very simple step by step, demo (see video at the end of read me) of save values in database to use in multiple sessions.

This simple app will help you understand
- How to add and access data in dynamoDB and use in multiple sessions

# Pre-requisite
- Go through previous samples - 1 to 4 (One level up in the folder structure)
- Create an account and login for
- https://developer.amazon.com
- https://aws.amazon.com

# Video
Watch this video to learn the steps.

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/kNDfJEOKN5A/0.jpg)](https://www.youtube.com/watch?v=kNDfJEOKN5A&feature=youtu.be)
