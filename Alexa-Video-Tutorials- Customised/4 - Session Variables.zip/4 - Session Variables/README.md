# Alexa - Session Variables

A very simple step by step, demo (see video at the end of read me) of retaining variables in a single session.

This simple app will help you understand
- How to add and access a session variable

# Pre-requisite
- Go through previous samples - 1 to 3 (One level up in the folder structure)
- Create an account and login for
- https://developer.amazon.com
- https://aws.amazon.com

# Video
Watch this video to learn the steps to create predefined slot application.

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/MRV48SKDyEc/0.jpg)](https://www.youtube.com/watch?v=MRV48SKDyEc&feature=youtu.be)
