# Alexa-Slots-Pre-Defined

A very simple step by step, 7.03 minutes demo (see video at the end of read me) of developing very simple skill of using a predefined slot.

To know different types of slots, visit:
https://developer.amazon.com/public/solutions/alexa/alexa-skills-kit/docs/built-in-intent-ref/slot-type-reference#numbers-dates-and-times

This simple app will help you understand
- How to add a predefined slot in your app
- How to access the value of slot in your app

# Pre-requisite
- Go through previous sample - Hello World App - https://github.com/SunilSyal/Alexa-Video-Tutorials/tree/master/1%20-%20Hello%20World
- Create an account and login for
- https://developer.amazon.com
- https://aws.amazon.com

# Video
Watch this video to learn the steps to create predefined slot application.

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/DcRsZzncHVw/0.jpg)](https://www.youtube.com/watch?v=DcRsZzncHVw&t=9s)
