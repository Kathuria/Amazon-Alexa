# Alexa - Play Audio File

A very simple step by step, demo (see video at the end of read me) of playing an audio file as a response by Alexa.

This simple app will help you understand
- How to play an audio file in response

# Pre-requisite
- Go through previous samples - 1 to 5 (One level up in the folder structure)
- Create an account and login for
- https://developer.amazon.com
- https://aws.amazon.com

# Video
Watch this video to learn the steps.

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/QQcRgnWoyoM/0.jpg)](https://www.youtube.com/watch?v=QQcRgnWoyoM&feature=youtu.be)
