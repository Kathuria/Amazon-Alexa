# Alexa-Slots-Custom

A very simple step by step, demo (see video at the end of read me) of developing very simple skill of using a custom slot.

This simple app will help you understand
- How to add a custom slot in your app
- How to access the value of slot in your app

# Pre-requisite
- Go through previous sample - Hello World App - https://github.com/SunilSyal/Alexa-Video-Tutorials/tree/master/1%20-%20Hello%20World
- Go through previous sample - Slots - Pre-defined - https://github.com/SunilSyal/Alexa-Video-Tutorials/tree/master/2%20-%20Slots%20-%20Pre-defined
- Create an account and login for
- https://developer.amazon.com
- https://aws.amazon.com

# Video
Watch this video to learn the steps to create predefined slot application.

[![IMAGE ALT TEXT HERE](https://img.youtube.com/vi/szga4LzDyx8/0.jpg)](https://www.youtube.com/watch?v=szga4LzDyx8&feature=youtu.be)
