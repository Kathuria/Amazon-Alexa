# Alexa - Play Rhymes

Rhymes Music taken from https://www.youtube.com/watch?v=3gAZTtCiQc8

A skill that recites popular nursery rhymes!
Try it out now for some good times for your kids!


Current rhymes include:
Twinkle twinkle little star How I wonder what you are Up above the world so high Like a diamond in the sky Twinkle twinkle little star How I wonder what you are.   
Twinkle twinkle little star How I wonder what you are Up above the world so high Like a diamond in the sky Twinkle twinkle little star How I wonder what you are.   

Give feedback in comments below.
I will add more rhymes in this skill later on.


1, 2 What Shall We Do
0:11 - 1:38
https://www.youtube.com/watch?v=aUiswwr77L8

Hello Song
0:07 - 1:27
https://www.youtube.com/watch?v=fqfjfmAi-ug
https://s3-eu-west-1.amazonaws.com/aksongs/Rhymes/Hello_Song+48kbps+16000Hz.mp3
https://s3-eu-west-1.amazonaws.com/akimagebucket/Rhymes/Hello+Song+1200w+800h.png
https://s3-eu-west-1.amazonaws.com/akimagebucket/Rhymes/Hello+Song+720w+480h.png

Baa Baa Black Sheep
0:10 - 1:04
https://www.youtube.com/watch?v=SSeCirHFaik
https://s3-eu-west-1.amazonaws.com/aksongs/Rhymes/Baa_Baa_Black_Sheep+48kbps+16000Hz.mp3
https://s3-eu-west-1.amazonaws.com/akimagebucket/Rhymes/Baa_Baa_Black_Sheep+1200w+800h.png
https://s3-eu-west-1.amazonaws.com/akimagebucket/Rhymes/Baa_Baa_Black_Sheep+720w+480h.png
Wheels On The Bus
(Bus Wheels)
0:18 - 1:48
https://www.youtube.com/watch?v=L4ozHHp4MMc
https://s3-eu-west-1.amazonaws.com/aksongs/Rhymes/Wheels_On_The_Bus+48kbps+16000Hz.mp3
https://s3-eu-west-1.amazonaws.com/akimagebucket/Rhymes/Wheels_On_The_Bus+1200w+800h.png
https://s3-eu-west-1.amazonaws.com/akimagebucket/Rhymes/Wheels_On_The_Bus+720w+480h.png

Bath Song
0:17-1:47
https://www.youtube.com/watch?v=qhuGQp1AkjQ
https://s3-eu-west-1.amazonaws.com/aksongs/Rhymes/Bath_Song+48kbps+16000Hz.mp3
https://s3-eu-west-1.amazonaws.com/akimagebucket/Rhymes/Bath+Song+1200w+800h.jpeg
https://s3-eu-west-1.amazonaws.com/akimagebucket/Rhymes/Bath+Song+720w+480h.jpeg

Driving In My Car
(Drive Car)
0:10- 1:30
https://www.youtube.com/watch?v=f5vrYDXgVrs
https://s3-eu-west-1.amazonaws.com/aksongs/Rhymes/Driving_In_My_Car+48kbps+16000Hz.mp3
https://s3-eu-west-1.amazonaws.com/akimagebucket/Rhymes/Drive+Car+1200w+800h.jpeg
https://s3-eu-west-1.amazonaws.com/akimagebucket/Rhymes/Drive+Car+720w+480h.jpeg

Blue Whale 
0:17 - 1:47
https://www.youtube.com/watch?v=KQQ9MjKo-qc
https://s3-eu-west-1.amazonaws.com/aksongs/Rhymes/Blue_Whale+48kbps+16000Hz.mp3
https://s3-eu-west-1.amazonaws.com/akimagebucket/Rhymes/Blue+Whale+1200w+800h.jpeg
https://s3-eu-west-1.amazonaws.com/akimagebucket/Rhymes/Blue+Whale+720w+480h.jpeg

This Is The Way We Brush Our Teeth
(Brush Teeth)
0:07 - 1:37
https://www.youtube.com/watch?v=Pd4WnsXwdqw
https://s3-eu-west-1.amazonaws.com/aksongs/Rhymes/This_Is_The_Way_We_Brush_Our_Teeth+48kbps+16000Hz.mp3
https://s3-eu-west-1.amazonaws.com/akimagebucket/Rhymes/Brush+Teeth+1200w+800h.jpeg
https://s3-eu-west-1.amazonaws.com/akimagebucket/Rhymes/Brush+Teeth+720w+480h.jpeg

ABC Song
0:31 - 1:37
https://www.youtube.com/watch?v=QWM1_FQxD88
https://s3-eu-west-1.amazonaws.com/aksongs/Rhymes/ABC_Song+48kbps+16000Hz.mp3
https://s3-eu-west-1.amazonaws.com/akimagebucket/Rhymes/ABC_Song+1200w+800h.png
https://s3-eu-west-1.amazonaws.com/akimagebucket/Rhymes/ABC_Song+720w+480h.png